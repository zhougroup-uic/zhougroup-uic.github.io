bash run.sh 0.65 90 &
bash run.sh 0.70 90 &
bash run.sh 0.75 90 &
bash run.sh 0.80 90 &
wait
bash run.sh 0.85 90 &
bash run.sh 0.90 90 &
bash run.sh 0.95 90 &
bash run.sh 1.00 90 &
wait
bash run.sh 1.05 90 &
bash run.sh 1.10 90 &
bash run.sh 1.15 90 &
bash run.sh 0.65 84 &
wait
bash run.sh 0.70 84 &
bash run.sh 0.75 84 &
bash run.sh 0.80 84 &
bash run.sh 0.85 84 &
wait
bash run.sh 0.90 84 &
bash run.sh 0.95 84 &
bash run.sh 1.00 84 &
bash run.sh 1.05 84 &
wait
bash run.sh 1.10 84 &
bash run.sh 1.15 84 &
bash run.sh 0.65 78 &
bash run.sh 0.70 78 &
wait
bash run.sh 0.75 78 &
bash run.sh 0.80 78 &
bash run.sh 0.85 78 &
bash run.sh 0.90 78 &
wait
bash run.sh 0.95 78 &
bash run.sh 1.00 78 &
bash run.sh 1.05 78 &
bash run.sh 1.10 78 &
wait
bash run.sh 1.15 78 &
bash run.sh 0.65 72 &
bash run.sh 0.70 72 &
bash run.sh 0.75 72 &
wait
bash run.sh 0.80 72 &
bash run.sh 0.85 72 &
bash run.sh 0.90 72 &
bash run.sh 0.95 72 &
wait
bash run.sh 1.00 72 &
bash run.sh 1.05 72 &
bash run.sh 1.10 72 &
bash run.sh 1.15 72 &
wait
bash run.sh 0.65 66 &
bash run.sh 0.70 66 &
bash run.sh 0.75 66 &
bash run.sh 0.80 66 &
wait
bash run.sh 0.85 66 &
bash run.sh 0.90 66 &
bash run.sh 0.95 66 &
bash run.sh 1.00 66 &
wait
bash run.sh 1.05 66 &
bash run.sh 1.10 66 &
bash run.sh 1.15 66 &
bash run.sh 0.65 60 &
wait
bash run.sh 0.70 60 &
bash run.sh 0.75 60 &
bash run.sh 0.80 60 &
bash run.sh 0.85 60 &
wait
bash run.sh 0.90 60 &
bash run.sh 0.95 60 &
bash run.sh 1.00 60 &
bash run.sh 1.05 60 &
wait
bash run.sh 1.10 60 &
bash run.sh 1.15 60 &
bash run.sh 0.65 54 &
bash run.sh 0.70 54 &
wait
bash run.sh 0.75 54 &
bash run.sh 0.80 54 &
bash run.sh 0.85 54 &
bash run.sh 0.90 54 &
wait
bash run.sh 0.95 54 &
bash run.sh 1.00 54 &
bash run.sh 1.05 54 &
bash run.sh 1.10 54 &
wait
bash run.sh 1.15 54 &
bash run.sh 0.65 48 &
bash run.sh 0.70 48 &
bash run.sh 0.75 48 &
wait
bash run.sh 0.80 48 &
bash run.sh 0.85 48 &
bash run.sh 0.90 48 &
bash run.sh 0.95 48 &
wait
bash run.sh 1.00 48 &
bash run.sh 1.05 48 &
bash run.sh 1.10 48 &
bash run.sh 1.15 48 &
wait
bash run.sh 0.65 42 &
bash run.sh 0.70 42 &
bash run.sh 0.75 42 &
bash run.sh 0.80 42 &
wait
bash run.sh 0.85 42 &
bash run.sh 0.90 42 &
bash run.sh 0.95 42 &
bash run.sh 1.00 42 &
wait
bash run.sh 1.05 42 &
bash run.sh 1.10 42 &
bash run.sh 1.15 42 &
bash run.sh 0.65 36 &
wait
bash run.sh 0.70 36 &
bash run.sh 0.75 36 &
bash run.sh 0.80 36 &
bash run.sh 0.85 36 &
wait
bash run.sh 0.90 36 &
bash run.sh 0.95 36 &
bash run.sh 1.00 36 &
bash run.sh 1.05 36 &
wait
bash run.sh 1.10 36 &
bash run.sh 1.15 36 &
bash run.sh 0.65 30 &
bash run.sh 0.70 30 &
wait
bash run.sh 0.75 30 &
bash run.sh 0.80 30 &
bash run.sh 0.85 30 &
bash run.sh 0.90 30 &
wait
bash run.sh 0.95 30 &
bash run.sh 1.00 30 &
bash run.sh 1.05 30 &
bash run.sh 1.10 30 &
wait
bash run.sh 1.15 30 &
bash run.sh 0.65 24 &
bash run.sh 0.70 24 &
bash run.sh 0.75 24 &
wait
bash run.sh 0.80 24 &
bash run.sh 0.85 24 &
bash run.sh 0.90 24 &
bash run.sh 0.95 24 &
wait
bash run.sh 1.00 24 &
bash run.sh 1.05 24 &
bash run.sh 1.10 24 &
bash run.sh 1.15 24 &
wait
bash run.sh 0.65 18 &
bash run.sh 0.70 18 &
bash run.sh 0.75 18 &
bash run.sh 0.80 18 &
wait
bash run.sh 0.85 18 &
bash run.sh 0.90 18 &
bash run.sh 0.95 18 &
bash run.sh 1.00 18 &
wait
bash run.sh 1.05 18 &
bash run.sh 1.10 18 &
bash run.sh 1.15 18 &
bash run.sh 0.65 12 &
wait
bash run.sh 0.70 12 &
bash run.sh 0.75 12 &
bash run.sh 0.80 12 &
bash run.sh 0.85 12 &
wait
bash run.sh 0.90 12 &
bash run.sh 0.95 12 &
bash run.sh 1.00 12 &
bash run.sh 1.05 12 &
wait
bash run.sh 1.10 12 &
bash run.sh 1.15 12 &
bash run.sh 0.65 6 &
bash run.sh 0.70 6 &
wait
bash run.sh 0.75 6 &
bash run.sh 0.80 6 &
bash run.sh 0.85 6 &
bash run.sh 0.90 6 &
wait
bash run.sh 0.95 6 &
bash run.sh 1.00 6 &
bash run.sh 1.05 6 &
bash run.sh 1.10 6 &
wait
bash run.sh 1.15 6 &
wait
